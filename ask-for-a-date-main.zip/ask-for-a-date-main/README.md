# Çıkma Teklifi Troll.

## Merhabalar instagram hesabımı takip edip destek olursanız daha fazla benzer içerikler hazırlayabilirim.😊

[![Instagram](https://img.shields.io/badge/Instagram-%23E4405F.svg?&style=flat-square&logo=instagram&logoColor=white)](https://www.instagram.com/kodlama.dili/)
